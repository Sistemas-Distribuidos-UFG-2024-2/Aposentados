import socket

class Cliente:
    """ Essa classe simula o cliente dos servidores"""

    def __init__(self, ip_servidor, porta_servidor):
        self.ip_servidor = ip_servidor
        self.porta_servidor = porta_servidor

    def estabelecer_conexao(self):
        cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        cliente.connect((self.ip_servidor, self.porta_servidor))

        while True:
            mensagem = input("Envie uma mensagem ao servidor: ")
            cliente.send(mensagem.encode("utf-8")[:1024])

            resposta = cliente.recv(1024)
            resposta = resposta.decode("utf-8")

            if mensagem.lower() == "quit":
                print("Encerrando conexão...")
                break

            print(f"Mensagem recebida pelo cliente: {resposta}")

        print("Conexão com o servidor fechada!")
        cliente.close()

        return "encerrado"