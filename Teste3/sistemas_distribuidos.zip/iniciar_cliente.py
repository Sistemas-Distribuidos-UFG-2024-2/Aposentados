from cliente import Cliente

if __name__ == '__main__':

    tentativas_conexao = 0

    while tentativas_conexao < 3:
        try:
                ip_servidor = input("Insira o IP destinado ao servidor: ")
                porta_servidor = int(input("Insira a PORTA destinada ao servidor: "))  # Conversão para inteiro


                cliente = Cliente(ip_servidor=ip_servidor, porta_servidor=porta_servidor)
                teste = cliente.estabelecer_conexao()
        except:
            print("O servidor foi desconectado!")
            continue
        else:
            print("Conexão estabelecida com sucesso!")
        finally:
            tentativas_conexao += 1