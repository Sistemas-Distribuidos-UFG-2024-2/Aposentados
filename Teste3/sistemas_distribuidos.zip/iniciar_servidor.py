from servidor import Servidor
if __name__ == '__main__':

        try:
            ip_servidor = input("Insira o IP destinado ao servidor: ")
            porta_servidor = int(input("Insira a PORTA destinada ao servidor: "))  # Conversão para inteiro

            servidor = Servidor(ip=ip_servidor, porta=porta_servidor)  # Ajuste de nomes de parâmetros
            servidor.iniciar_servidor()
        except:
            print("Falha na conexão!")
        else:
            print("Conexão estabelecida com sucesso!")
