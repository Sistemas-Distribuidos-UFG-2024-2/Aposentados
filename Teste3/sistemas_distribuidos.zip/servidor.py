import socket

class Servidor:
    """ Essa classe modela um servidor"""

    def __init__(self, ip, porta):
        self.ip = ip
        self.porta = porta

    def iniciar_servidor(self):
        servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        servidor.bind((self.ip, self.porta))

        servidor.listen(5)  # Aumentar o número de conexões em espera

        print(f"Servidor disponível no caminho: http://{self.ip}:{self.porta}")

        client_socket, client_address = servidor.accept()

        print(f"Conexão estabelecida com {client_address[0]}:{client_address[1]}!")

        while True:
            try:
                request = client_socket.recv(1024)
                if not request:
                    break

                request_decoded = request.decode("utf-8")

                # Verifica se a mensagem é uma requisição HTTP
                if request_decoded.startswith("GET") or request_decoded.startswith("POST"):
                    print("Requisição HTTP recebida, encerrando conexão.")
                    client_socket.send("Requisição HTTP não suportada!".encode("utf-8"))
                    break

                print(f"Mensagem recebida pelo servidor: {request_decoded}")

                resposta = "Recebido".encode("utf-8")

                client_socket.send(resposta)

            except Exception as e:
                print(f"Erro durante a conexão: {e}")
                break

        client_socket.close()
        print(f"Conexão com {client_address[0]}:{client_address[1]} encerrada.")

